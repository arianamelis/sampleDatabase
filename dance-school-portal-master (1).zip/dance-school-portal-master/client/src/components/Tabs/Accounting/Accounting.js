import React, { Component,  } from "react";
import { Container, Row, Col } from 'react-bootstrap';

class Accounting extends Component {
  render () {
    return (
      <Container>
        <h3>Accounting Tab Content</h3>
        <h6>TODO</h6>
        <ul>
          <li>Add accounting functionality</li>
        </ul>
      </Container>
    );
  }
}

export default Accounting;
import React, { Component,  } from "react";
import { Container, Row, Col } from 'react-bootstrap';

class Orders extends Component {
  render () {
    return (
      <Container>
        <h3>Orders Tab Content</h3>
        <h6>TODO</h6>
        <ul>
          <li>Add order support functionality</li>
        </ul>
      </Container>
    );
  }
}

export default Orders;
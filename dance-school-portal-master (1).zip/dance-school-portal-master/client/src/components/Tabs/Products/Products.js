import React, { Component,  } from "react";
import { Container, Row, Col } from 'react-bootstrap';

class Products extends Component {
  render () {
    return (
      <Container>
        <h3>Products Tab Content</h3>
        <h6>TODO</h6>
        <ul>
          <li>Add product support functionality</li>
        </ul>
      </Container>
    );
  }
}

export default Products;
